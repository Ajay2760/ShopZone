import {
  type User,
  type InsertUser,
  type Product,
  type InsertProduct,
  type Address,
  type InsertAddress,
  type CartItem,
  type InsertCartItem,
  type WishlistItem,
  type InsertWishlistItem,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
} from "@shared/schema";
import { nanoid } from "nanoid";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Products
  getAllProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;

  // Addresses
  getAddressesByUser(userId: string): Promise<Address[]>;
  getAddress(id: string): Promise<Address | undefined>;
  createAddress(address: InsertAddress): Promise<Address>;
  deleteAddress(id: string): Promise<void>;

  // Cart
  getCartByUser(userId: string): Promise<CartItem[]>;
  getCartItem(userId: string, productId: string): Promise<CartItem | undefined>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartQuantity(id: string, quantity: number): Promise<CartItem>;
  removeFromCart(id: string): Promise<void>;
  clearCart(userId: string): Promise<void>;

  // Wishlist
  getWishlistByUser(userId: string): Promise<WishlistItem[]>;
  getWishlistItem(userId: string, productId: string): Promise<WishlistItem | undefined>;
  addToWishlist(item: InsertWishlistItem): Promise<WishlistItem>;
  removeFromWishlist(id: string): Promise<void>;

  // Orders
  getOrdersByUser(userId: string): Promise<Order[]>;
  getAllOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrderStatus(id: string, status: string): Promise<Order>;
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private addresses: Map<string, Address>;
  private cartItems: Map<string, CartItem>;
  private wishlistItems: Map<string, WishlistItem>;
  private orders: Map<string, Order>;
  private orderItems: Map<string, OrderItem>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.addresses = new Map();
    this.cartItems = new Map();
    this.wishlistItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();

    this.seedProducts();
  }

  private seedProducts() {
    const productsData: InsertProduct[] = [
      {
        title: "Premium Wireless Headphones",
        price: "299.99",
        image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400",
        category: "Electronics",
        stock: 15,
        description: "High-quality wireless headphones with noise cancellation",
      },
      {
        title: "Smart Fitness Watch",
        price: "199.99",
        image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400",
        category: "Electronics",
        stock: 8,
        description: "Track your fitness goals with this advanced smartwatch",
      },
      {
        title: "Modern Laptop Computer",
        price: "1299.99",
        image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400",
        category: "Electronics",
        stock: 5,
        description: "Powerful laptop for work and entertainment",
      },
      {
        title: "Leather Messenger Bag",
        price: "149.99",
        image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400",
        category: "Fashion",
        stock: 0,
        description: "Stylish leather bag for everyday use",
      },
      {
        title: "Wireless Smartphone",
        price: "899.99",
        image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400",
        category: "Electronics",
        stock: 12,
        description: "Latest smartphone with advanced features",
      },
      {
        title: "Bluetooth Speaker",
        price: "79.99",
        image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400",
        category: "Electronics",
        stock: 20,
        description: "Portable speaker with excellent sound quality",
      },
    ];

    productsData.forEach(product => {
      const id = nanoid();
      this.products.set(id, {
        id,
        title: product.title,
        price: product.price,
        image: product.image,
        category: product.category,
        stock: product.stock ?? 0,
        description: product.description ?? null,
        createdAt: new Date(),
      });
    });
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = nanoid();
    // First user is automatically admin, rest are regular users
    const isFirstUser = this.users.size === 0;
    const user: User = {
      id,
      email: insertUser.email,
      displayName: insertUser.displayName ?? null,
      photoURL: insertUser.photoURL ?? null,
      isAdmin: isFirstUser ? 1 : (insertUser.isAdmin ?? 0),
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  // Products
  async getAllProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = nanoid();
    const product: Product = {
      id,
      title: insertProduct.title,
      price: insertProduct.price,
      image: insertProduct.image,
      category: insertProduct.category,
      stock: insertProduct.stock ?? 0,
      description: insertProduct.description ?? null,
      createdAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  // Addresses
  async getAddressesByUser(userId: string): Promise<Address[]> {
    return Array.from(this.addresses.values()).filter(addr => addr.userId === userId);
  }

  async getAddress(id: string): Promise<Address | undefined> {
    return this.addresses.get(id);
  }

  async createAddress(insertAddress: InsertAddress): Promise<Address> {
    const id = nanoid();
    const address: Address = {
      ...insertAddress,
      id,
      createdAt: new Date(),
    };
    this.addresses.set(id, address);
    return address;
  }

  async deleteAddress(id: string): Promise<void> {
    this.addresses.delete(id);
  }

  // Cart
  async getCartByUser(userId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values()).filter(item => item.userId === userId);
  }

  async getCartItem(userId: string, productId: string): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      item => item.userId === userId && item.productId === productId
    );
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    const id = nanoid();
    const item: CartItem = {
      id,
      userId: insertItem.userId,
      productId: insertItem.productId,
      quantity: insertItem.quantity ?? 1,
      createdAt: new Date(),
    };
    this.cartItems.set(id, item);
    return item;
  }

  async updateCartQuantity(id: string, quantity: number): Promise<CartItem> {
    const item = this.cartItems.get(id);
    if (!item) throw new Error("Cart item not found");
    
    const updated = { ...item, quantity };
    this.cartItems.set(id, updated);
    return updated;
  }

  async removeFromCart(id: string): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(userId: string): Promise<void> {
    const userItems = await this.getCartByUser(userId);
    userItems.forEach(item => this.cartItems.delete(item.id));
  }

  // Wishlist
  async getWishlistByUser(userId: string): Promise<WishlistItem[]> {
    return Array.from(this.wishlistItems.values()).filter(item => item.userId === userId);
  }

  async getWishlistItem(userId: string, productId: string): Promise<WishlistItem | undefined> {
    return Array.from(this.wishlistItems.values()).find(
      item => item.userId === userId && item.productId === productId
    );
  }

  async addToWishlist(insertItem: InsertWishlistItem): Promise<WishlistItem> {
    const id = nanoid();
    const item: WishlistItem = {
      ...insertItem,
      id,
      createdAt: new Date(),
    };
    this.wishlistItems.set(id, item);
    return item;
  }

  async removeFromWishlist(id: string): Promise<void> {
    this.wishlistItems.delete(id);
  }

  // Orders
  async getOrdersByUser(userId: string): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getAllOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort(
      (a, b) => b.createdAt.getTime() - a.createdAt.getTime()
    );
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = nanoid();
    const order: Order = {
      id,
      userId: insertOrder.userId,
      addressId: insertOrder.addressId,
      status: insertOrder.status ?? "On Process",
      total: insertOrder.total,
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrderStatus(id: string, status: string): Promise<Order> {
    const order = this.orders.get(id);
    if (!order) throw new Error("Order not found");
    
    const updated = { ...order, status };
    this.orders.set(id, updated);
    return updated;
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(item => item.orderId === orderId);
  }

  async createOrderItem(insertItem: InsertOrderItem): Promise<OrderItem> {
    const id = nanoid();
    const item: OrderItem = {
      ...insertItem,
      id,
    };
    this.orderItems.set(id, item);
    return item;
  }
}

export const storage = new MemStorage();
