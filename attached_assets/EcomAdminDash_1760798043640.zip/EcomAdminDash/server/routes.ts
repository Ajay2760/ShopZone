import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertProductSchema,
  insertAddressSchema,
  insertCartItemSchema,
  insertWishlistItemSchema,
  insertOrderSchema,
  insertOrderItemSchema,
  insertUserSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByEmail(userData.email);
      
      if (existingUser) {
        return res.json(existingUser);
      }
      
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/users/email/:email", async (req, res) => {
    try {
      const user = await storage.getUserByEmail(req.params.email);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Product routes
  app.get("/api/products", async (req, res) => {
    try {
      let products = await storage.getAllProducts();
      
      // Search filter
      const search = req.query.search as string;
      if (search) {
        const searchLower = search.toLowerCase();
        products = products.filter(
          p => p.title.toLowerCase().includes(searchLower) || 
               p.category.toLowerCase().includes(searchLower)
        );
      }
      
      // Sort
      const sort = req.query.sort as string;
      if (sort === "price-low") {
        products.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
      } else if (sort === "price-high") {
        products.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
      } else if (sort === "name-asc") {
        products.sort((a, b) => a.title.localeCompare(b.title));
      } else if (sort === "name-desc") {
        products.sort((a, b) => b.title.localeCompare(a.title));
      }
      
      res.json(products);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Cart routes
  app.get("/api/cart/:userId", async (req, res) => {
    try {
      const cartItems = await storage.getCartByUser(req.params.userId);
      
      // Populate with product details
      const itemsWithProducts = await Promise.all(
        cartItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product,
          };
        })
      );
      
      res.json(itemsWithProducts);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const cartData = insertCartItemSchema.parse(req.body);
      
      // Validate product exists and has stock
      const product = await storage.getProduct(cartData.productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      if (product.stock === 0) {
        return res.status(400).json({ error: "Product out of stock" });
      }
      
      // Check if item already in cart
      const existing = await storage.getCartItem(cartData.userId, cartData.productId);
      if (existing) {
        const updated = await storage.updateCartQuantity(existing.id, existing.quantity + (cartData.quantity ?? 1));
        return res.json(updated);
      }
      
      const cartItem = await storage.addToCart(cartData);
      res.json(cartItem);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/cart/:id", async (req, res) => {
    try {
      const { quantity } = req.body;
      if (quantity < 1) {
        return res.status(400).json({ error: "Quantity must be at least 1" });
      }
      
      const updated = await storage.updateCartQuantity(req.params.id, quantity);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      await storage.removeFromCart(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Wishlist routes
  app.get("/api/wishlist/:userId", async (req, res) => {
    try {
      const wishlistItems = await storage.getWishlistByUser(req.params.userId);
      
      // Populate with product details
      const itemsWithProducts = await Promise.all(
        wishlistItems.map(async (item) => {
          const product = await storage.getProduct(item.productId);
          return {
            ...item,
            product,
          };
        })
      );
      
      res.json(itemsWithProducts);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/wishlist", async (req, res) => {
    try {
      const wishlistData = insertWishlistItemSchema.parse(req.body);
      
      // Validate product exists and has stock
      const product = await storage.getProduct(wishlistData.productId);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      if (product.stock === 0) {
        return res.status(400).json({ error: "Cannot add out of stock items to wishlist" });
      }
      
      // Check if already in wishlist
      const existing = await storage.getWishlistItem(wishlistData.userId, wishlistData.productId);
      if (existing) {
        return res.json(existing);
      }
      
      const wishlistItem = await storage.addToWishlist(wishlistData);
      res.json(wishlistItem);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/wishlist/:id", async (req, res) => {
    try {
      await storage.removeFromWishlist(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Address routes
  app.get("/api/addresses/:userId", async (req, res) => {
    try {
      const addresses = await storage.getAddressesByUser(req.params.userId);
      res.json(addresses);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/addresses", async (req, res) => {
    try {
      const addressData = insertAddressSchema.parse(req.body);
      const address = await storage.createAddress(addressData);
      res.json(address);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.delete("/api/addresses/:id", async (req, res) => {
    try {
      await storage.deleteAddress(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Order routes
  app.get("/api/orders/user/:userId", async (req, res) => {
    try {
      const orders = await storage.getOrdersByUser(req.params.userId);
      
      // Populate with items and address
      const ordersWithDetails = await Promise.all(
        orders.map(async (order) => {
          const items = await storage.getOrderItems(order.id);
          const address = await storage.getAddress(order.addressId);
          return {
            ...order,
            items,
            address,
            createdAt: order.createdAt.toISOString(),
          };
        })
      );
      
      res.json(ordersWithDetails);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.get("/api/orders", async (req, res) => {
    try {
      // Get admin email from query (passed by frontend)
      const adminEmail = req.query.adminEmail as string;
      if (!adminEmail) {
        return res.status(401).json({ error: "Unauthorized - admin email required" });
      }
      
      // Verify user is admin
      const adminUser = await storage.getUserByEmail(adminEmail);
      if (!adminUser || adminUser.isAdmin !== 1) {
        return res.status(403).json({ error: "Forbidden - admin access required" });
      }
      
      const orders = await storage.getAllOrders();
      
      // Populate with user and items count
      const ordersWithDetails = await Promise.all(
        orders.map(async (order) => {
          const user = await storage.getUser(order.userId);
          const items = await storage.getOrderItems(order.id);
          return {
            ...order,
            user,
            itemCount: items.length,
            createdAt: order.createdAt.toISOString(),
          };
        })
      );
      
      res.json(ordersWithDetails);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.post("/api/orders", async (req, res) => {
    try {
      const { userId, addressId, items } = req.body;
      
      if (!items || items.length === 0) {
        return res.status(400).json({ error: "Order must have at least one item" });
      }
      
      // Calculate total
      const total = items.reduce((sum: number, item: any) => {
        return sum + (parseFloat(item.price) * item.quantity);
      }, 0);
      
      // Create order
      const orderData = insertOrderSchema.parse({
        userId,
        addressId,
        total: total.toFixed(2),
        status: "On Process",
      });
      
      const order = await storage.createOrder(orderData);
      
      // Create order items
      for (const item of items) {
        const orderItemData = insertOrderItemSchema.parse({
          orderId: order.id,
          productId: item.productId,
          title: item.title,
          price: item.price,
          quantity: item.quantity,
          image: item.image,
        });
        await storage.createOrderItem(orderItemData);
      }
      
      // Clear cart
      await storage.clearCart(userId);
      
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  app.patch("/api/orders/:id/status", async (req, res) => {
    try {
      const { status, adminEmail } = req.body;
      
      if (!adminEmail) {
        return res.status(401).json({ error: "Unauthorized - admin email required" });
      }
      
      // Verify user is admin
      const adminUser = await storage.getUserByEmail(adminEmail);
      if (!adminUser || adminUser.isAdmin !== 1) {
        return res.status(403).json({ error: "Forbidden - admin access required" });
      }
      
      if (!["On Process", "Shipped", "Delivered"].includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }
      
      const updated = await storage.updateOrderStatus(req.params.id, status);
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
