# ShopHub - E-Commerce Application

A modern, full-stack e-commerce application built with React, TypeScript, Express, and Firebase Authentication. This project demonstrates a complete online shopping experience with user authentication, product management, shopping cart, wishlist, and order tracking features.

## 🎯 Project Overview

ShopHub is a comprehensive e-commerce platform that allows users to:
- Browse and search products with real-time filtering and sorting
- Add products to cart and wishlist (with stock validation)
- Manage multiple shipping addresses
- Complete secure checkout and place orders
- Track order status (On Process → Shipped → Delivered)
- Access admin panel for order management

## 🚀 Features

### User Features
- **Google OAuth Authentication**: Secure login using Firebase Authentication
- **Product Browsing**: View all products with search and sort functionality
- **Stock Management**: Products with stock=0 are automatically blocked from cart and wishlist
- **Shopping Cart**: Add/remove items, update quantities, view cart total
- **Wishlist**: Save favorite products for later purchase
- **Multi-Address Management**: Save and select from multiple shipping addresses
- **Order Placement**: Complete checkout with address selection (payment gateway coming soon)
- **Order History**: View past orders with status tracking
- **User Dashboard**: Centralized view of wishlist, cart, orders, and addresses

### Admin Features
- **Order Management Dashboard**: View all customer orders
- **Status Updates**: Update order status (On Process, Shipped, Delivered)
- **Customer Information**: View customer details and order summaries

## 🛠 Technology Stack

### Frontend
- **React 18** with TypeScript
- **Wouter** for routing
- **TanStack Query** for data fetching and caching
- **Tailwind CSS** for styling
- **Shadcn UI** for component library
- **Firebase SDK** for authentication

### Backend
- **Express.js** with TypeScript
- **In-memory storage** for data persistence
- **Zod** for request validation
- **Drizzle ORM** for schema management

### Infrastructure
- **Vite** for build tooling
- **Firebase** for Google OAuth
- **Replit** for hosting and development

## 📋 Requirements Checklist

### ✅ Admin Simulation & Product Management
- [x] Products stored with categories and stock count
- [x] All products displayed dynamically on frontend
- [x] Dynamic search and sorting functionality
- [x] Stock=0 products blocked from cart
- [x] Stock=0 products blocked from wishlist

### ✅ User Authentication & Dashboard
- [x] Google OAuth login via Firebase
- [x] "My Account" shown in nav after login
- [x] Logout functionality
- [x] User Dashboard with:
  - [x] Wishlist (saved products)
  - [x] Cart (added products)
  - [x] Order History (confirmed orders)

### ✅ Checkout & Order Flow
- [x] Cart with quantity management
- [x] Multiple address support
- [x] Address selection during checkout
- [x] Order confirmation (payment gateway mocked)
- [x] Default order status: "On Process"
- [x] Admin can update status to "Shipped" or "Delivered"
- [x] Users can see updated status in Order History

## 🔧 Setup Instructions

### Prerequisites
- Node.js 20+
- Firebase project with Google OAuth enabled
- Replit account (or local environment)

### Firebase Configuration

1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Add a web app to your project
3. Enable Google sign-in under Authentication > Sign-in method
4. Add your Replit Dev URL to Authorized domains (Authentication > Settings > Authorized domains)
5. Copy the following values from your Firebase project settings:
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_APP_ID`
   - `VITE_FIREBASE_API_KEY`

6. Add these as Replit Secrets or create a `.env` file:
```bash
VITE_FIREBASE_PROJECT_ID=your-project-id
VITE_FIREBASE_APP_ID=your-app-id
VITE_FIREBASE_API_KEY=your-api-key
```

### Installation

```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

The application will be available at `http://localhost:5000` (or your Replit URL).

## 📁 Project Structure

```
shophub/
├── client/                    # Frontend React application
│   ├── src/
│   │   ├── components/       # Reusable UI components
│   │   │   ├── Navbar.tsx
│   │   │   ├── ProductCard.tsx
│   │   │   ├── CartItemCard.tsx
│   │   │   ├── OrderCard.tsx
│   │   │   ├── AddressCard.tsx
│   │   │   ├── SearchBar.tsx
│   │   │   └── ui/          # Shadcn UI components
│   │   ├── contexts/        # React contexts
│   │   │   └── AuthContext.tsx
│   │   ├── pages/           # Page components
│   │   │   ├── Home.tsx
│   │   │   ├── Products.tsx
│   │   │   ├── Cart.tsx
│   │   │   ├── Checkout.tsx
│   │   │   ├── Dashboard.tsx
│   │   │   └── Admin.tsx
│   │   ├── lib/             # Utilities
│   │   │   ├── firebase.ts  # Firebase configuration
│   │   │   └── queryClient.ts
│   │   └── App.tsx          # Main app component
├── server/                   # Backend Express application
│   ├── routes.ts            # API endpoints
│   ├── storage.ts           # In-memory data storage
│   └── index.ts             # Server entry point
├── shared/                   # Shared types and schemas
│   └── schema.ts            # Data models and validation
└── package.json
```

## 🔌 API Endpoints

### Products
- `GET /api/products` - Get all products (supports search and sort query params)
- `GET /api/products/:id` - Get product by ID

### Cart
- `GET /api/cart/:userId` - Get user's cart items
- `POST /api/cart` - Add item to cart
- `PATCH /api/cart/:id` - Update item quantity
- `DELETE /api/cart/:id` - Remove item from cart

### Wishlist
- `GET /api/wishlist/:userId` - Get user's wishlist
- `POST /api/wishlist` - Add item to wishlist
- `DELETE /api/wishlist/:id` - Remove item from wishlist

### Addresses
- `GET /api/addresses/:userId` - Get user's addresses
- `POST /api/addresses` - Create new address
- `DELETE /api/addresses/:id` - Delete address

### Orders
- `GET /api/orders/user/:userId` - Get user's orders
- `GET /api/orders` - Get all orders (admin)
- `POST /api/orders` - Create new order
- `PATCH /api/orders/:id/status` - Update order status (admin)

### Users
- `POST /api/users` - Create or update user
- `GET /api/users/email/:email` - Get user by email

## 🎨 Design Features

- **Responsive Design**: Works seamlessly on mobile, tablet, and desktop
- **Dark Mode**: Toggle between light and dark themes
- **Professional UI**: Clean, modern interface using Shadcn components
- **Real-time Updates**: Cart count and order status update instantly
- **Stock Indicators**: Visual badges showing product availability
- **Status Tracking**: Color-coded order status badges

## 🔐 Security Features

- Firebase Authentication for secure user login
- Protected routes requiring authentication
- Admin access control (first user becomes admin)
- Server-side admin verification for order management endpoints
- Stock validation preventing out-of-stock purchases
- Input validation using Zod schemas

**Note**: For interview demonstration purposes, admin authorization uses a simplified approach. In a production environment, you would implement Firebase Admin SDK on the server to verify ID tokens and extract user claims securely.

## 🚀 Deployment

When ready to deploy after the interview:

1. After publishing on Replit, add your production URL to Firebase Authorized domains
2. Update environment variables for production
3. The app is automatically deployed and accessible via your Replit URL

## 📝 Testing the Application

1. **Login**: Click "Login" and sign in with Google
2. **Browse Products**: Navigate to "Products" to view all items
3. **Add to Cart**: Click "Add to Cart" on products with stock
4. **Add to Wishlist**: Click the heart icon on in-stock products
5. **View Dashboard**: Access "My Dashboard" to see wishlist, cart, and orders
6. **Checkout**: Go to cart and click "Proceed to Checkout"
7. **Add Address**: Create a new shipping address
8. **Place Order**: Select address and confirm order
9. **Admin Panel**: Access "/admin" to manage order statuses
10. **Update Status**: Change order status and verify in user's order history

## 🎯 Interview Project Compliance

This project fully implements all requirements from the interview task:

✅ **Admin Simulation & Product Management**
- REST API for product storage with categories and stock
- Dynamic product display with search and sorting
- Stock validation preventing cart/wishlist additions when stock=0

✅ **User Authentication & Dashboard**
- Google OAuth login via Firebase
- My Account navigation with logout
- Dashboard with Wishlist, Cart, and Order History

✅ **Checkout & Order Flow**
- Multi-address management
- Address selection in cart
- Order confirmation with mocked payment
- Order status management (On Process → Shipped → Delivered)
- Real-time status updates visible to users

## 👨‍💻 Development Notes

- **In-Memory Storage**: Data persists during runtime but resets on server restart. This demonstrates the full application flow without database complexity.
- **Seeded Products**: 6 sample products are automatically loaded on server start
- **Mock Payment**: Payment gateway integration is prepared but not implemented (as per requirements)
- **Admin Access**: The first user to register automatically becomes an admin. This is a simple approach for interview demonstration purposes. In production, you would implement proper Firebase Admin SDK token verification on the server side.

## 📧 Support

For questions or issues, please refer to the code comments or contact the developer.

## 📄 License

This project was created as an interview assignment and is available for review and evaluation purposes.

---

**Built with ❤️ for the React Developer interview assignment**
