import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup } from "@/components/ui/radio-group";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import AddressCard from "@/components/AddressCard";
import { CheckCircle2 } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface Address {
  id: string;
  userId: string;
  name: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
}

interface CartItemWithProduct {
  id: string;
  userId: string;
  productId: string;
  quantity: number;
  product: {
    id: string;
    title: string;
    price: string;
    image: string;
  };
}

export default function Checkout() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [selectedAddress, setSelectedAddress] = useState("");
  const [isOrderPlaced, setIsOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState("");
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [newAddress, setNewAddress] = useState({
    name: "",
    street: "",
    city: "",
    state: "",
    zipCode: "",
    phone: "",
  });

  const { data: addresses = [] } = useQuery<Address[]>({
    queryKey: ["/api/addresses", user?.uid],
    enabled: !!user,
  });

  const { data: cartItems = [] } = useQuery<CartItemWithProduct[]>({
    queryKey: ["/api/cart", user?.uid],
    enabled: !!user,
  });

  const addAddressMutation = useMutation({
    mutationFn: async () => {
      if (!user) return;

      return apiRequest("/api/addresses", {
        method: "POST",
        body: JSON.stringify({
          userId: user.uid,
          ...newAddress,
        }),
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/addresses"] });
      setSelectedAddress(data.id);
      setShowAddressForm(false);
      setNewAddress({
        name: "",
        street: "",
        city: "",
        state: "",
        zipCode: "",
        phone: "",
      });
      toast({
        title: "Address added",
        description: "Your address has been saved",
      });
    },
  });

  const placeOrderMutation = useMutation({
    mutationFn: async () => {
      if (!user || !selectedAddress) return;

      const items = cartItems.map(item => ({
        productId: item.productId,
        title: item.product.title,
        price: item.product.price,
        quantity: item.quantity,
        image: item.product.image,
      }));

      return apiRequest("/api/orders", {
        method: "POST",
        body: JSON.stringify({
          userId: user.uid,
          addressId: selectedAddress,
          items,
        }),
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      setOrderId(data.id);
      setIsOrderPlaced(true);
      toast({
        title: "Order placed!",
        description: "Your order has been confirmed",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to place order",
        variant: "destructive",
      });
    },
  });

  const handlePlaceOrder = () => {
    if (!selectedAddress) {
      toast({
        title: "Select address",
        description: "Please select a shipping address",
        variant: "destructive",
      });
      return;
    }

    placeOrderMutation.mutate();
  };

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    addAddressMutation.mutate();
  };

  if (!user) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <h2 className="mb-2 font-serif text-2xl font-bold">Please login to checkout</h2>
          <p className="mb-6 text-muted-foreground">
            You need to be logged in to place an order
          </p>
        </div>
      </div>
    );
  }

  if (isOrderPlaced) {
    return (
      <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-chart-2/10">
            <CheckCircle2 className="h-12 w-12 text-chart-2" />
          </div>
          <h2 className="mb-2 font-serif text-2xl font-bold">Order Placed Successfully!</h2>
          <p className="mb-2 text-muted-foreground">
            Your order has been confirmed and is being processed.
          </p>
          <p className="mb-6 font-medium" data-testid="text-order-number">
            Order #{orderId}
          </p>
          <Button onClick={() => setLocation('/dashboard')} data-testid="button-view-orders">
            View My Orders
          </Button>
        </div>
      </div>
    );
  }

  const subtotal = cartItems.reduce((sum, item) => sum + parseFloat(item.product.price) * item.quantity, 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="mb-8 font-serif text-3xl font-bold md:text-4xl">
        Checkout
      </h1>

      <div className="grid gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Select Shipping Address</CardTitle>
          </CardHeader>
          <CardContent>
            <RadioGroup value={selectedAddress} onValueChange={setSelectedAddress}>
              <div className="space-y-4">
                {addresses.map((address) => (
                  <AddressCard
                    key={address.id}
                    {...address}
                    selectable
                    isSelected={selectedAddress === address.id}
                    onSelect={setSelectedAddress}
                  />
                ))}
              </div>
            </RadioGroup>
            
            {!showAddressForm && (
              <Button
                variant="outline"
                className="mt-4"
                onClick={() => setShowAddressForm(true)}
                data-testid="button-add-address"
              >
                Add New Address
              </Button>
            )}

            {showAddressForm && (
              <form onSubmit={handleAddAddress} className="mt-4 space-y-4 border-t pt-4">
                <h3 className="font-medium">New Address</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={newAddress.name}
                      onChange={(e) => setNewAddress({ ...newAddress, name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={newAddress.phone}
                      onChange={(e) => setNewAddress({ ...newAddress, phone: e.target.value })}
                      required
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="street">Street Address</Label>
                    <Input
                      id="street"
                      value={newAddress.street}
                      onChange={(e) => setNewAddress({ ...newAddress, street: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="city">City</Label>
                    <Input
                      id="city"
                      value={newAddress.city}
                      onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="state">State</Label>
                    <Input
                      id="state"
                      value={newAddress.state}
                      onChange={(e) => setNewAddress({ ...newAddress, state: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="zipCode">ZIP Code</Label>
                    <Input
                      id="zipCode"
                      value={newAddress.zipCode}
                      onChange={(e) => setNewAddress({ ...newAddress, zipCode: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button type="submit" disabled={addAddressMutation.isPending}>
                    Save Address
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddressForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Items ({cartItems.length})</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax (8%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span className="text-chart-2">FREE</span>
              </div>
              <div className="border-t pt-2">
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span data-testid="text-checkout-total">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <Button
              className="w-full"
              size="lg"
              onClick={handlePlaceOrder}
              disabled={!selectedAddress || placeOrderMutation.isPending}
              data-testid="button-place-order"
            >
              {placeOrderMutation.isPending ? "Placing Order..." : "Place Order"}
            </Button>
            
            <p className="mt-4 text-center text-xs text-muted-foreground">
              Payment gateway integration coming soon
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
