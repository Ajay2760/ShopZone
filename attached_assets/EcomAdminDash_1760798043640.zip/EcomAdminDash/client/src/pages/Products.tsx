import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import ProductCard from "@/components/ProductCard";
import SearchBar from "@/components/SearchBar";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Product } from "@shared/schema";

export default function Products() {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("default");
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products", { search: searchQuery, sort: sortBy }],
  });

  const addToCartMutation = useMutation({
    mutationFn: async (productId: string) => {
      if (!user) {
        toast({
          title: "Please login",
          description: "You need to be logged in to add items to cart",
          variant: "destructive",
        });
        return;
      }

      const product = products.find(p => p.id === productId);
      if (!product) return;

      return apiRequest("/api/cart", {
        method: "POST",
        body: JSON.stringify({
          userId: user.uid,
          productId,
          quantity: 1,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: "Product has been added to your cart",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add to cart",
        variant: "destructive",
      });
    },
  });

  const addToWishlistMutation = useMutation({
    mutationFn: async (productId: string) => {
      if (!user) {
        toast({
          title: "Please login",
          description: "You need to be logged in to add items to wishlist",
          variant: "destructive",
        });
        return;
      }

      return apiRequest("/api/wishlist", {
        method: "POST",
        body: JSON.stringify({
          userId: user.uid,
          productId,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wishlist"] });
      toast({
        title: "Added to wishlist",
        description: "Product has been added to your wishlist",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add to wishlist",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex items-center justify-center py-12">
          <p className="text-lg text-muted-foreground">Loading products...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="mb-8 font-serif text-3xl font-bold md:text-4xl">
        All Products
      </h1>

      <div className="mb-8">
        <SearchBar
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          sortBy={sortBy}
          onSortChange={setSortBy}
        />
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            id={parseInt(product.id.slice(0, 8), 36)}
            title={product.title}
            price={parseFloat(product.price)}
            image={product.image}
            category={product.category}
            stock={product.stock}
            onAddToCart={() => addToCartMutation.mutate(product.id)}
            onAddToWishlist={() => addToWishlistMutation.mutate(product.id)}
            onProductClick={(id) => console.log('Product clicked:', id)}
          />
        ))}
      </div>

      {products.length === 0 && (
        <div className="py-12 text-center">
          <p className="text-lg text-muted-foreground">No products found</p>
        </div>
      )}
    </div>
  );
}
