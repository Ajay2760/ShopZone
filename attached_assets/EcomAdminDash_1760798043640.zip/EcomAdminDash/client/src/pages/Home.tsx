import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, ShoppingBag, Heart, Package } from "lucide-react";
import heroImg from '@assets/generated_images/E-commerce_hero_banner_image_1d1ab9b6.png';

export default function Home() {
  return (
    <div className="flex flex-col">
      <section
        className="relative h-[500px] overflow-hidden bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImg})` }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-black/30" />
        <div className="relative mx-auto flex h-full max-w-7xl flex-col items-center justify-center px-4 text-center text-white">
          <h1 className="mb-4 font-serif text-4xl font-bold md:text-6xl" data-testid="text-hero-title">
            Welcome to ShopHub
          </h1>
          <p className="mb-8 max-w-2xl text-lg md:text-xl text-white/90" data-testid="text-hero-subtitle">
            Discover amazing products at great prices. Shop electronics, fashion, and more with fast shipping.
          </p>
          <Link href="/products">
            <Button size="lg" className="gap-2" data-testid="button-shop-now">
              Shop Now
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      <section className="py-12 md:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="mb-12 text-center font-serif text-3xl font-bold md:text-4xl">
            Why Shop With Us?
          </h2>
          
          <div className="grid gap-8 md:grid-cols-3">
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <ShoppingBag className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold">Wide Selection</h3>
              <p className="text-muted-foreground">
                Browse thousands of products across multiple categories
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Heart className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold">Wishlist Feature</h3>
              <p className="text-muted-foreground">
                Save your favorite items for later with our wishlist
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <Package className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mb-2 font-serif text-xl font-semibold">Order Tracking</h3>
              <p className="text-muted-foreground">
                Track your orders from processing to delivery
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
