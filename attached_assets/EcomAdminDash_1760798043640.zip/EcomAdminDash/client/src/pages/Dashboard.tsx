import { useQuery, useMutation } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Heart, ShoppingCart, Package, MapPin } from "lucide-react";
import ProductCard from "@/components/ProductCard";
import CartItemCard from "@/components/CartItemCard";
import OrderCard from "@/components/OrderCard";
import AddressCard from "@/components/AddressCard";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";

interface WishlistItemWithProduct {
  id: string;
  userId: string;
  productId: string;
  product: {
    id: string;
    title: string;
    price: string;
    image: string;
    category: string;
    stock: number;
  };
}

interface CartItemWithProduct {
  id: string;
  userId: string;
  productId: string;
  quantity: number;
  product: {
    id: string;
    title: string;
    price: string;
    image: string;
    stock: number;
  };
}

interface OrderWithDetails {
  id: string;
  userId: string;
  status: string;
  total: string;
  createdAt: string;
  items: any[];
}

interface Address {
  id: string;
  userId: string;
  name: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
}

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: wishlistItems = [] } = useQuery<WishlistItemWithProduct[]>({
    queryKey: ["/api/wishlist", user?.uid],
    enabled: !!user,
  });

  const { data: cartItems = [] } = useQuery<CartItemWithProduct[]>({
    queryKey: ["/api/cart", user?.uid],
    enabled: !!user,
  });

  const { data: orders = [] } = useQuery<OrderWithDetails[]>({
    queryKey: ["/api/orders/user", user?.uid],
    enabled: !!user,
  });

  const { data: addresses = [] } = useQuery<Address[]>({
    queryKey: ["/api/addresses", user?.uid],
    enabled: !!user,
  });

  const removeFromWishlistMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/wishlist/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/wishlist"] });
      toast({
        title: "Removed from wishlist",
        description: "Item has been removed from your wishlist",
      });
    },
  });

  const addToCartMutation = useMutation({
    mutationFn: async (productId: string) => {
      if (!user) return;

      return apiRequest("/api/cart", {
        method: "POST",
        body: JSON.stringify({
          userId: user.uid,
          productId,
          quantity: 1,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: "Product has been added to your cart",
      });
    },
  });

  const updateCartQuantityMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: string; quantity: number }) => {
      return apiRequest(`/api/cart/${id}`, {
        method: "PATCH",
        body: JSON.stringify({ quantity }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  const removeFromCartMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest(`/api/cart/${id}`, {
        method: "DELETE",
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    },
  });

  if (!user) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-center py-12 text-center">
          <h2 className="mb-2 font-serif text-2xl font-bold">Please login to view dashboard</h2>
          <p className="mb-6 text-muted-foreground">
            You need to be logged in to access your dashboard
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="mb-8 font-serif text-3xl font-bold md:text-4xl">
        My Dashboard
      </h1>

      <Tabs defaultValue="wishlist" className="w-full">
        <TabsList className="grid w-full grid-cols-4 mb-8">
          <TabsTrigger value="wishlist" className="gap-2" data-testid="tab-wishlist">
            <Heart className="h-4 w-4" />
            <span className="hidden sm:inline">Wishlist</span>
          </TabsTrigger>
          <TabsTrigger value="cart" className="gap-2" data-testid="tab-cart">
            <ShoppingCart className="h-4 w-4" />
            <span className="hidden sm:inline">Cart</span>
          </TabsTrigger>
          <TabsTrigger value="orders" className="gap-2" data-testid="tab-orders">
            <Package className="h-4 w-4" />
            <span className="hidden sm:inline">Orders</span>
          </TabsTrigger>
          <TabsTrigger value="addresses" className="gap-2" data-testid="tab-addresses">
            <MapPin className="h-4 w-4" />
            <span className="hidden sm:inline">Addresses</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="wishlist">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {wishlistItems.map((item) => (
              <ProductCard
                key={item.id}
                id={parseInt(item.id.slice(0, 8), 36)}
                title={item.product.title}
                price={parseFloat(item.product.price)}
                image={item.product.image}
                category={item.product.category}
                stock={item.product.stock}
                onAddToCart={() => addToCartMutation.mutate(item.productId)}
                onAddToWishlist={() => removeFromWishlistMutation.mutate(item.id)}
                onProductClick={(id) => console.log('Product clicked:', id)}
              />
            ))}
          </div>
          {wishlistItems.length === 0 && (
            <div className="py-12 text-center">
              <Heart className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <p className="text-lg text-muted-foreground">Your wishlist is empty</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="cart">
          <div className="space-y-4">
            {cartItems.map((item) => (
              <CartItemCard
                key={item.id}
                id={parseInt(item.id.slice(0, 8), 36)}
                title={item.product.title}
                price={parseFloat(item.product.price)}
                image={item.product.image}
                quantity={item.quantity}
                onUpdateQuantity={(_, qty) => updateCartQuantityMutation.mutate({ id: item.id, quantity: qty })}
                onRemove={() => removeFromCartMutation.mutate(item.id)}
              />
            ))}
          </div>
          {cartItems.length === 0 && (
            <div className="py-12 text-center">
              <ShoppingCart className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <p className="text-lg text-muted-foreground">Your cart is empty</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="orders">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {orders.map((order) => (
              <OrderCard
                key={order.id}
                id={order.id}
                status={order.status as any}
                date={new Date(order.createdAt).toLocaleDateString()}
                total={parseFloat(order.total)}
                itemCount={order.items?.length || 0}
                onOrderClick={(id) => console.log('Order clicked:', id)}
              />
            ))}
          </div>
          {orders.length === 0 && (
            <div className="py-12 text-center">
              <Package className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <p className="text-lg text-muted-foreground">No orders yet</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="addresses">
          <div className="grid gap-4 sm:grid-cols-2">
            {addresses.map((address) => (
              <AddressCard key={address.id} {...address} />
            ))}
          </div>
          {addresses.length === 0 && (
            <div className="py-12 text-center">
              <MapPin className="mx-auto mb-4 h-12 w-12 text-muted-foreground" />
              <p className="text-lg text-muted-foreground mb-4">No addresses saved</p>
              <Button onClick={() => setLocation('/checkout')}>
                Add Address
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
