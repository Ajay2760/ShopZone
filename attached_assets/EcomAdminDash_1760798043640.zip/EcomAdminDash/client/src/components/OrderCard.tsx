import { Card, CardContent, CardHeader } from "@/components/ui/card";
import StatusBadge from "./StatusBadge";
import { Package } from "lucide-react";

type OrderStatus = "On Process" | "Shipped" | "Delivered";

interface OrderCardProps {
  id: string;
  status: OrderStatus;
  date: string;
  total: number;
  itemCount: number;
  onOrderClick?: (id: string) => void;
}

export default function OrderCard({
  id,
  status,
  date,
  total,
  itemCount,
  onOrderClick,
}: OrderCardProps) {
  return (
    <Card
      className="hover-elevate cursor-pointer transition-shadow"
      onClick={() => onOrderClick?.(id)}
      data-testid={`card-order-${id}`}
    >
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
        <div className="flex items-center gap-2">
          <Package className="h-5 w-5 text-muted-foreground" />
          <h3 className="font-semibold" data-testid={`text-order-id-${id}`}>Order #{id}</h3>
        </div>
        <StatusBadge status={status} />
      </CardHeader>
      <CardContent className="grid gap-2 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Date</span>
          <span className="font-medium" data-testid={`text-order-date-${id}`}>{date}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Items</span>
          <span className="font-medium" data-testid={`text-order-items-${id}`}>{itemCount}</span>
        </div>
        <div className="flex justify-between border-t pt-2">
          <span className="text-muted-foreground">Total</span>
          <span className="text-lg font-bold" data-testid={`text-order-total-${id}`}>${total.toFixed(2)}</span>
        </div>
      </CardContent>
    </Card>
  );
}
