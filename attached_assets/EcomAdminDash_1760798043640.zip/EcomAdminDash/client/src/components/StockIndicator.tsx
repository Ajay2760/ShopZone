import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle } from "lucide-react";

interface StockIndicatorProps {
  stock: number;
}

export default function StockIndicator({ stock }: StockIndicatorProps) {
  const inStock = stock > 0;

  return (
    <Badge
      variant={inStock ? "default" : "destructive"}
      className={inStock ? "bg-chart-2" : ""}
      data-testid={`badge-stock-${inStock ? 'in' : 'out'}`}
    >
      {inStock ? (
        <>
          <CheckCircle2 className="mr-1 h-3 w-3" />
          In Stock ({stock})
        </>
      ) : (
        <>
          <XCircle className="mr-1 h-3 w-3" />
          Out of Stock
        </>
      )}
    </Badge>
  );
}
