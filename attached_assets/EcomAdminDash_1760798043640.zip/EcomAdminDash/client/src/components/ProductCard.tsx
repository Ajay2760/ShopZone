import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, ShoppingCart } from "lucide-react";
import StockIndicator from "./StockIndicator";
import { useState } from "react";

interface ProductCardProps {
  id: number;
  title: string;
  price: number;
  image: string;
  category: string;
  stock: number;
  onAddToCart?: (id: number) => void;
  onAddToWishlist?: (id: number) => void;
  onProductClick?: (id: number) => void;
}

export default function ProductCard({
  id,
  title,
  price,
  image,
  category,
  stock,
  onAddToCart,
  onAddToWishlist,
  onProductClick,
}: ProductCardProps) {
  const [isWishlisted, setIsWishlisted] = useState(false);
  const inStock = stock > 0;

  const handleWishlistClick = () => {
    if (inStock) {
      setIsWishlisted(!isWishlisted);
      onAddToWishlist?.(id);
    }
  };

  const handleAddToCart = () => {
    if (inStock) {
      onAddToCart?.(id);
    }
  };

  return (
    <Card className="group overflow-hidden hover-elevate transition-shadow" data-testid={`card-product-${id}`}>
      <div
        className="aspect-[4/3] overflow-hidden bg-muted cursor-pointer"
        onClick={() => onProductClick?.(id)}
      >
        <img
          src={image}
          alt={title}
          className="h-full w-full object-cover transition-transform group-hover:scale-105"
        />
      </div>
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1" data-testid={`text-category-${id}`}>
          {category}
        </p>
        <h3 className="font-serif text-lg font-medium mb-2 line-clamp-2" data-testid={`text-title-${id}`}>
          {title}
        </h3>
        <div className="flex items-center justify-between mb-2">
          <p className="text-2xl font-bold" data-testid={`text-price-${id}`}>
            ${price.toFixed(2)}
          </p>
          <StockIndicator stock={stock} />
        </div>
      </CardContent>
      <CardFooter className="flex gap-2 p-4 pt-0">
        <Button
          className="flex-1"
          onClick={handleAddToCart}
          disabled={!inStock}
          data-testid={`button-add-to-cart-${id}`}
        >
          <ShoppingCart className="mr-2 h-4 w-4" />
          Add to Cart
        </Button>
        <Button
          variant="outline"
          size="icon"
          onClick={handleWishlistClick}
          disabled={!inStock}
          className={isWishlisted ? "text-destructive" : ""}
          data-testid={`button-add-to-wishlist-${id}`}
        >
          <Heart className={`h-4 w-4 ${isWishlisted ? "fill-current" : ""}`} />
        </Button>
      </CardFooter>
    </Card>
  );
}
