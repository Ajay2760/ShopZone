import { Badge } from "@/components/ui/badge";

type OrderStatus = "On Process" | "Shipped" | "Delivered";

interface StatusBadgeProps {
  status: OrderStatus;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  const getStatusStyles = () => {
    switch (status) {
      case "Delivered":
        return "bg-chart-2 text-white";
      case "Shipped":
        return "bg-chart-3 text-white";
      case "On Process":
        return "bg-chart-3/80 text-white";
      default:
        return "";
    }
  };

  return (
    <Badge className={`${getStatusStyles()}`} data-testid={`badge-status-${status.toLowerCase().replace(' ', '-')}`}>
      {status}
    </Badge>
  );
}
