import OrderCard from '../OrderCard';

export default function OrderCardExample() {
  return (
    <div className="max-w-md space-y-4">
      <OrderCard
        id="12345"
        status="On Process"
        date="Oct 15, 2025"
        total={1599.98}
        itemCount={3}
        onOrderClick={(id) => console.log('Order clicked:', id)}
      />
      <OrderCard
        id="12346"
        status="Shipped"
        date="Oct 10, 2025"
        total={299.99}
        itemCount={1}
        onOrderClick={(id) => console.log('Order clicked:', id)}
      />
      <OrderCard
        id="12347"
        status="Delivered"
        date="Oct 5, 2025"
        total={799.99}
        itemCount={2}
        onOrderClick={(id) => console.log('Order clicked:', id)}
      />
    </div>
  );
}
