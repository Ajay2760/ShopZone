import Navbar from '../Navbar';

export default function NavbarExample() {
  return (
    <Navbar
      cartCount={3}
      isLoggedIn={true}
      isAdmin={true}
      userName="John Doe"
      userEmail="john@example.com"
      onLogin={() => console.log('Login clicked')}
      onLogout={() => console.log('Logout clicked')}
    />
  );
}
