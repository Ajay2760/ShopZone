import StockIndicator from '../StockIndicator';

export default function StockIndicatorExample() {
  return (
    <div className="flex gap-2">
      <StockIndicator stock={10} />
      <StockIndicator stock={0} />
    </div>
  );
}
