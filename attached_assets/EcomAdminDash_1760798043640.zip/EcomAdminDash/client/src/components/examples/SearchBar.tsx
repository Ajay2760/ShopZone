import SearchBar from '../SearchBar';
import { useState } from 'react';

export default function SearchBarExample() {
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState('default');

  return (
    <SearchBar
      searchQuery={search}
      onSearchChange={setSearch}
      sortBy={sort}
      onSortChange={setSort}
    />
  );
}
