import ProductCard from '../ProductCard';
import headphonesImg from '@assets/generated_images/Wireless_headphones_product_image_f5bb6f46.png';

export default function ProductCardExample() {
  return (
    <div className="max-w-sm">
      <ProductCard
        id={1}
        title="Premium Wireless Headphones"
        price={299.99}
        image={headphonesImg}
        category="Electronics"
        stock={15}
        onAddToCart={(id) => console.log('Add to cart:', id)}
        onAddToWishlist={(id) => console.log('Add to wishlist:', id)}
        onProductClick={(id) => console.log('Product clicked:', id)}
      />
    </div>
  );
}
