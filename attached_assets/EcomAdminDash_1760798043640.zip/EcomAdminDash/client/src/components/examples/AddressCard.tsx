import AddressCard from '../AddressCard';

export default function AddressCardExample() {
  return (
    <div className="max-w-md space-y-4">
      <AddressCard
        id="1"
        name="John Doe"
        street="123 Main Street, Apt 4B"
        city="New York"
        state="NY"
        zipCode="10001"
        phone="(555) 123-4567"
      />
      <AddressCard
        id="2"
        name="John Doe"
        street="456 Oak Avenue"
        city="Los Angeles"
        state="CA"
        zipCode="90001"
        phone="(555) 987-6543"
        selectable={true}
        isSelected={true}
      />
    </div>
  );
}
