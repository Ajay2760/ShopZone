import CartItemCard from '../CartItemCard';
import laptopImg from '@assets/generated_images/Modern_laptop_product_image_17eddab5.png';

export default function CartItemCardExample() {
  return (
    <CartItemCard
      id={1}
      title="Modern Laptop Computer"
      price={1299.99}
      image={laptopImg}
      quantity={1}
      onUpdateQuantity={(id, qty) => console.log('Update quantity:', id, qty)}
      onRemove={(id) => console.log('Remove item:', id)}
    />
  );
}
