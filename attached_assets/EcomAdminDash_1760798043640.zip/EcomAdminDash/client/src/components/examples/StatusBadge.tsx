import StatusBadge from '../StatusBadge';

export default function StatusBadgeExample() {
  return (
    <div className="flex gap-2">
      <StatusBadge status="On Process" />
      <StatusBadge status="Shipped" />
      <StatusBadge status="Delivered" />
    </div>
  );
}
