import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Phone } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";

interface AddressCardProps {
  id: string;
  name: string;
  street: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  isSelected?: boolean;
  onSelect?: (id: string) => void;
  selectable?: boolean;
}

export default function AddressCard({
  id,
  name,
  street,
  city,
  state,
  zipCode,
  phone,
  isSelected = false,
  onSelect,
  selectable = false,
}: AddressCardProps) {
  const addressContent = (
    <CardContent className="p-4">
      <div className="flex items-start gap-3">
        {selectable && (
          <RadioGroupItem value={id} id={`address-${id}`} className="mt-1" />
        )}
        <div className="flex-1">
          <h4 className="font-medium mb-2" data-testid={`text-address-name-${id}`}>{name}</h4>
          <div className="flex items-start gap-2 text-sm text-muted-foreground mb-1">
            <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
            <div data-testid={`text-address-details-${id}`}>
              <p>{street}</p>
              <p>{city}, {state} {zipCode}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Phone className="h-4 w-4" />
            <p data-testid={`text-address-phone-${id}`}>{phone}</p>
          </div>
        </div>
      </div>
    </CardContent>
  );

  if (selectable) {
    return (
      <Label htmlFor={`address-${id}`} className="cursor-pointer">
        <Card
          className={`hover-elevate transition-all ${isSelected ? "ring-2 ring-primary" : ""}`}
          data-testid={`card-address-${id}`}
        >
          {addressContent}
        </Card>
      </Label>
    );
  }

  return (
    <Card data-testid={`card-address-${id}`}>
      {addressContent}
    </Card>
  );
}
