import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Trash2 } from "lucide-react";

interface CartItemCardProps {
  id: number;
  title: string;
  price: number;
  image: string;
  quantity: number;
  onUpdateQuantity?: (id: number, quantity: number) => void;
  onRemove?: (id: number) => void;
}

export default function CartItemCard({
  id,
  title,
  price,
  image,
  quantity,
  onUpdateQuantity,
  onRemove,
}: CartItemCardProps) {
  const total = price * quantity;

  return (
    <Card data-testid={`card-cart-item-${id}`}>
      <CardContent className="p-4">
        <div className="flex gap-4">
          <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-md bg-muted">
            <img src={image} alt={title} className="h-full w-full object-cover" />
          </div>
          
          <div className="flex flex-1 flex-col gap-2">
            <h3 className="font-medium line-clamp-2" data-testid={`text-item-title-${id}`}>{title}</h3>
            <p className="text-sm text-muted-foreground" data-testid={`text-item-price-${id}`}>
              ${price.toFixed(2)} each
            </p>
            
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onUpdateQuantity?.(id, quantity - 1)}
                  disabled={quantity <= 1}
                  data-testid={`button-decrease-quantity-${id}`}
                >
                  <Minus className="h-3 w-3" />
                </Button>
                <span className="w-8 text-center font-medium" data-testid={`text-quantity-${id}`}>
                  {quantity}
                </span>
                <Button
                  variant="outline"
                  size="icon"
                  className="h-8 w-8"
                  onClick={() => onUpdateQuantity?.(id, quantity + 1)}
                  data-testid={`button-increase-quantity-${id}`}
                >
                  <Plus className="h-3 w-3" />
                </Button>
              </div>
              
              <div className="flex items-center gap-4">
                <p className="text-lg font-bold" data-testid={`text-item-total-${id}`}>
                  ${total.toFixed(2)}
                </p>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 text-destructive"
                  onClick={() => onRemove?.(id)}
                  data-testid={`button-remove-${id}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
