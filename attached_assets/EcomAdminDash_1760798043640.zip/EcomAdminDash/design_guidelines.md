# E-Commerce Application Design Guidelines

## Design Approach

**Selected Approach:** Hybrid - E-commerce Reference + Material Design System

**Justification:** This is a utility-focused e-commerce application requiring professional UI patterns for product browsing, cart management, and admin functionality. Drawing from established e-commerce leaders (Shopify, Amazon) while maintaining Material Design consistency ensures both familiarity and polish for the interview evaluation.

**Key Design Principles:**
- Clear information hierarchy for product discovery
- Trustworthy, professional aesthetic
- Efficient task completion (add to cart, checkout)
- Clean admin interface for order management
- Consistent component patterns throughout

---

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 220 70% 50% (Professional blue for CTAs, navigation)
- Surface: 0 0% 100% (White backgrounds)
- Surface Secondary: 220 15% 97% (Light gray for cards, sections)
- Text Primary: 220 15% 20% (Near-black for readability)
- Text Secondary: 220 10% 50% (Gray for supporting text)
- Success: 142 76% 36% (Green for stock available, order delivered)
- Warning: 38 92% 50% (Orange for low stock, order shipped)
- Error: 0 84% 60% (Red for out of stock, remove actions)

**Dark Mode:**
- Primary: 220 70% 60% (Lighter blue for contrast)
- Surface: 220 15% 12% (Dark gray background)
- Surface Secondary: 220 15% 18% (Elevated cards)
- Text Primary: 220 15% 95% (Off-white)
- Text Secondary: 220 10% 65% (Light gray)

### B. Typography

**Font Families:**
- Primary: 'Inter' (via Google Fonts) - Clean, modern sans-serif for all UI text
- Secondary: 'Poppins' (via Google Fonts) - Headlines and product titles for impact

**Scale:**
- Hero/Page Titles: text-4xl md:text-5xl, font-bold, font-secondary
- Section Headers: text-2xl md:text-3xl, font-semibold
- Product Titles: text-lg, font-medium, font-secondary
- Body Text: text-base, font-normal
- Small/Meta Text: text-sm, font-normal (prices, status, timestamps)
- Buttons: text-sm md:text-base, font-medium, uppercase tracking-wide

### C. Layout System

**Spacing Primitives:** Consistently use Tailwind units: 2, 4, 8, 12, 16, 24, 32
- Component padding: p-4 md:p-8
- Section spacing: py-12 md:py-24, px-4 md:px-8
- Card spacing: p-6, gap-4
- Grid gaps: gap-4 md:gap-8

**Container Strategy:**
- Max width: max-w-7xl mx-auto
- Product grids: grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4
- Dashboard layout: Two-column on desktop (sidebar + content), stacked on mobile

### D. Component Library

**Navigation Bar:**
- Sticky header with logo left, navigation center, account/cart icons right
- Dark surface with light text for strong contrast
- Shopping cart icon with badge showing item count
- User avatar with dropdown menu (My Account, Dashboard, Logout)

**Product Cards:**
- Vertical layout: Image (4:3 ratio) → Title → Price → Stock status → Action buttons
- Elevated shadow on hover (shadow-md → shadow-lg transition)
- Stock indicator: Green badge "In Stock" or Red badge "Out of Stock"
- Dual action buttons: "Add to Cart" (primary) + Heart icon for wishlist
- Disabled state for out-of-stock items with opacity-50

**Shopping Cart:**
- Line items with: Thumbnail image (square, 80px) | Product details | Quantity controls | Price | Remove button
- Quantity controls: Minus/Plus buttons flanking number display
- Cart summary card (sticky on desktop): Subtotal, Tax, Total with prominent "Checkout" button
- Empty state: Icon + message "Your cart is empty" + "Continue Shopping" CTA

**Dashboard Sections:**
- Tab navigation: Wishlist | Cart | Order History | Addresses
- Wishlist: Grid layout matching product cards, with "Move to Cart" option
- Order History: Timeline-style cards with Order # header, status badge (color-coded), items list, total
- Address cards: Name, full address, phone with "Edit" and "Delete" actions

**Admin Panel:**
- Clean table layout for orders: Order ID | Customer | Date | Total | Status dropdown | Actions
- Status dropdown with color-coded options: On Process (yellow), Shipped (orange), Delivered (green)
- Inline editing with auto-save confirmation

**Forms:**
- Address form: Stacked inputs with clear labels above each field
- Input styling: Rounded borders, focus ring (primary color), proper spacing
- Checkout: Two-column layout (Address selection left, Order summary right on desktop)

**Buttons:**
- Primary: Filled with primary color, white text, rounded-md, shadow-sm
- Secondary: Outline style with primary border, primary text
- Danger: Red background for destructive actions (Remove from cart)
- Icon buttons: Square with padding, hover background change

**Status Badges:**
- Pill-shaped with appropriate color: px-3 py-1 rounded-full text-xs font-medium
- On Process: Yellow background with dark text
- Shipped: Orange background with white text
- Delivered: Green background with white text
- Out of Stock: Red background with white text

### E. Page-Specific Layouts

**Home Page:**
- Hero section: Large product showcase image with overlay text and "Shop Now" CTA (h-96 md:h-[500px])
- Featured categories: 3-column grid with category images and titles
- Popular products: 4-column grid (responsive)

**Products Page:**
- Sidebar filters (categories, price range) on desktop, collapsible on mobile
- Search bar prominent at top with sort dropdown (Price: Low to High, etc.)
- Product grid fills remaining space

**Checkout:**
- Multi-step visual indicator at top (Address → Review → Confirm)
- Address selection: Radio cards showing saved addresses + "Add New" option
- Order review: Cart items list + selected address preview
- Confirmation screen: Success checkmark, order number, estimated delivery

**User Dashboard:**
- Sidebar navigation (avatar, name, tabs) on desktop
- Full-width tab content area
- Responsive: Tabs become horizontal scrolling on mobile

### F. Animations

**Minimal, Purposeful Motion:**
- Card hover: Smooth shadow elevation (transition-shadow duration-200)
- Button hover: Slight scale (hover:scale-105 transition-transform)
- Page transitions: Subtle fade-in for route changes
- Cart badge: Gentle pulse when items added
- No complex animations or scroll effects

---

## Images

**Hero Section:**
- Large, high-quality lifestyle image showing diverse products in use
- Dimensions: 1920x800px (desktop), maintain 16:9 aspect ratio
- Overlay: Dark gradient (bottom to top) for text readability
- Image placement: Full-width background with content centered

**Product Images:**
- Clean product photography on white/neutral backgrounds
- Consistent aspect ratio: 4:3 for all product cards
- High resolution for detail views in cart/checkout
- Fallback placeholder for missing images

**Category Images:**
- Lifestyle shots representing each category
- Square format (1:1) for category grid
- Subtle overlay for category name text

**Empty State Illustrations:**
- Simple line-art style icons for empty cart, wishlist, orders
- Centered with supporting text below
- Muted colors matching secondary text

---

## Interaction Patterns

- Product cards: Click anywhere to view details, dedicated buttons for cart/wishlist
- Cart quantity: Immediate update on button click with visual feedback
- Address selection: Radio buttons with card-style containers (full card clickable)
- Admin status update: Dropdown with instant save on selection change
- Search: Real-time filtering as user types (debounced 300ms)
- Wishlist heart: Toggle state with smooth color transition
- Form validation: Inline error messages below fields with red text

---

This design creates a professional, functional e-commerce experience optimized for the interview requirements while maintaining visual polish and usability throughout all user flows.